import simulator;

int main()
{
	using namespace Simulator;

	CarSimulator carSim;
	BikeSimulator bikeSim;
}
