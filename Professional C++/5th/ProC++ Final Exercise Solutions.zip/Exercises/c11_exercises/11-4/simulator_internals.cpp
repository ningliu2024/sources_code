module simulator:internals;

namespace Simulator
{
	double convertMilesToKm(double miles)
	{
		return miles * 1.6;
	}
}
