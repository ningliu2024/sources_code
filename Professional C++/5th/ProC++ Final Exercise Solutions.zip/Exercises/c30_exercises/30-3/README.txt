This code is meant to be compiled and executed by the Microsoft
Visual C++ Testing Framework.

It has been tested with Visual C++ 2019.