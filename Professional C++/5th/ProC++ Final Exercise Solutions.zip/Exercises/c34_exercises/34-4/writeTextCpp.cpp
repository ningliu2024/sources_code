#include "writeTextCpp.h"
import <iostream>;

using namespace std;

void writeTextFromCpp(const char* text)
{
	cout << "C++ is writing:" << endl;
	cout << text << endl;
}